# vhdl-stopwatch
simple stopwatch using hdl for spartan board
